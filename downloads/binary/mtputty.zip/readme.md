1. 同步到非中文/无空格的目录  

2. 安装主题  

    "color themes"目录下  
    选择需要的主题,双击,添加进注册表

3. 安装bin

    安装 winscp.exe  
    添加 kitty目录 到 path  
    或者添加 putty目录 到 path  

    `kitty`支持直接调用`winscp`启动文件传输

4. ppk生成

    使用 `PUTTYGEN.EXE` 转换

5. putty简单使用

    `putty -load SessionX -ssh -X -P 端口 -i 个人秘钥.ppk -loghost title -m 本地执行文件 用户名@IP地址`

    `putty -load SessionX -P 端口 -pw 密码 用户名@IP地址`

    若`-loghost title`生效,需load对应`Session` -> `Terminal` -> `Features` -> 勾选`Disable remote-controlled window title changing`

6. 代理设置
   
    需load对应`Session` -> `Connection` -> `Proxy`

7. 将注册表配置转换为port版本

    `"Colour0"="1,1,1"` ==> `\Colour0\1,1,1\`
